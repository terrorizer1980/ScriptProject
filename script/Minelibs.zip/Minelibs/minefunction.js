function Timer(_Timer) {
    mc.timer.timerSpeed = _Timer;
}
function getIP() {
 if (mc.getCurrentServerData() != null) {
    return (mc.getCurrentServerData().serverIP.toLowerCase());
  }
}
function ChatF(_Chat) {
    Chat.print("§8[§b§lMinemoraScript§8] §f§l" + _Chat)
}
Math.radians = function(degrees) {
    return degrees * Math.PI / 180;
};
function ChatP(_Chat) {
    Chat.print("§8[§b§lMinemoraSpeed§8] §f" + _Chat)
};
function ChatA(_Chat) {
    Chat.print("§8[§b§lMinemoraGlide§8] §f" + _Chat)
};
function Timer(_Timer) {
    mc.timer.timerSpeed = _Timer;
}
function setSpeed(_speed) {
    var playerYaw = Math.radians(mc.thePlayer.rotationYaw);
    mc.thePlayer.motionX = _speed * -Math.sin(playerYaw);
    mc.thePlayer.motionZ = _speed * Math.cos(playerYaw);
};
function setDiagSpeed(_speed) {
    var playerYaw = Math.radians(mc.thePlayer.rotationYaw + 90);
    mc.thePlayer.motionX = _speed * -Math.sin(playerYaw);
    mc.thePlayer.motionZ = _speed * Math.cos(playerYaw);
};
function setMoveSpeed(_speed) {
    if (mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown()) {
        setDiagSpeed(_speed*-mc.thePlayer.moveStrafing);
    } else {
        setSpeed(_speed * mc.thePlayer.moveForward);
    }
};
function copyToClipboard(string) {
    var stringSelection = new StringSelection(string);
    var clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    clipboard.setContents(stringSelection, null);
}
//from switchfall
function inVoid() {
    if (mc.thePlayer.posY < -1.8) {
        return true;
    } else {
        return mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0, -(mc.thePlayer.posY / 2), 0).expand(0, (mc.thePlayer.posY / 2), 0)).isEmpty();
    }
}
function Stop() {
    mc.gameSettings.keyBindForward.pressed = false;
    mc.gameSettings.keyBindBack.pressed = false;
    mc.gameSettings.keyBindLeft.pressed = false;
    mc.gameSettings.keyBindRight.pressed = false;
} 
var Freeze = moduleManager.getModule("Freeze");
var Scaffold = moduleManager.getModule("Scaffold");
var InventoryCleaner = moduleManager.getModule("InventoryCleaner");
var noFallModule = moduleManager.getModule("NoFall");
var Keyboard = Java.type("org.lwjgl.input.Keyboard");

var S02PacketChat = Java.type("net.minecraft.network.play.server.S02PacketChat");
var EntityPlayer = Java.type('net.minecraft.entity.player.EntityPlayer');
var thePlayer = Java.type("net.ccbluex.liquidbounce.utils.MovementUtils");
var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');

var _1autoplay = 0;
var _1MinemoraDetector = 0;
var _1True = 0;
var _1InvC;
var _1FL;
var _1target;
var _1antistepladder;
var _1AntiVoid;
var _1AntiVoidChat;
var _1AntiVoidFalse;

var _2MSpeed = 0;
var _2DTick = 0;
var _2FTick = 0;
var _2BTick = 1;
var _2Safez;

var _3Tick = 0;
var _3MinemoraDetector = 0;
var _3True = 0;
