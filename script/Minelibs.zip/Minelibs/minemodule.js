var MinemoraManagerModule = {
    name: "MinemoraManager",
    description: "Manager For Minemora",
    category: "Misc",
    tag: "MS",
    settings: {
        X: Setting.boolean({
                name: "General: ",
                default: false
        }),
        Help: Setting.boolean({
                name: "Help",
                default: true
        }),
        About: Setting.boolean({
                name: "About",
                default: true
        }),
        XX: Setting.boolean({
                name: " ",
                default: false
        }),
        XXX: Setting.boolean({
                name: "Tools: ",
                default: false
        }),
        AutoPlay: Setting.boolean({
                name: "Autoplay",
                default: true
        }),
        ScaffoldInvClean: Setting.boolean({
                name: "NoScaffoldInvCleaner",
                default: true
        }),
        AntiStepLadder: Setting.boolean({
                name: "AntiStepLadder",
                default: true
        }),
        AntiVoid: Setting.boolean({
                name: "PearlVoid",
                default: true
        }),
        XXXX: Setting.boolean({
                name: " ",
                default: false
        }),
        XXXXX: Setting.boolean({
                name: "FastLadder: ",
                default: false
        }),
        FastLadder: Setting.boolean({
                name: "FastLadder",
                default: true
        }),
        FastLadderMode: Setting.list({
                name: "FastLadderMode",
                default: "Space&Walk",
                values: ["Walk","Space","Space&Walk","Space+Walk","Always"]
        }),
        FastLadderSpeed: Setting.float({
                name: "FastLadderMotion",
                default: 0.1185,
                min: 0,
                max: 1
        }),
        FastLadderTimer: Setting.float({
                name: "FastLadderTimer",
                default: 2,
                min: 0,
                max: 5
        }),
        XXXXXXX: Setting.boolean({
                name: " ",
                default: false
        }),
        XXXXXXXX: Setting.boolean({
                name: "AutoL: ",
                default: false
        }),
        AutoL: Setting.boolean({
                name: "AutoL",
                default: true
        }),
        AutoLMode: Setting.list({
                name: "AutoLMode",
                default: "L",
                values: ["L","Custom"]
        }),
        CustomAutoL: Setting.text({
                name: "CustomAutoLWord",
                default: " "
        }),
        XXXXXXXXX: Setting.boolean({
                name: " ",
                default: false
        }),
        Debug: Setting.boolean({
                name: "Debug",
                default: true
        })
    }
}

var MinemoraSpeedModule = {
    name: "MinemoraSpeed",
    description: "Speed For Minemora",
    category: "Misc",
    tag: "NULL",
    settings: {
        BM: Setting.list({
            name: "BoostMode",
            default: "Timer",
            values: ["None","Timer","TimerGround","Speed"]
        }),
        Safewalk: Setting.boolean({
            name: "Safewalk",
            default: true
        }),
        X: Setting.boolean({
                name: " ",
                default: false
        }),
        XX: Setting.boolean({
                name: "Timer: ",
                default: false
        }),
        MFTi: Setting.float({
            name: "Timer",
            default: 4,
            min: 1,
            max: 10
        }),
        XXX: Setting.boolean({
                name: " ",
                default: false
        }),
        XXXX: Setting.boolean({
                name: "TimerGround: ",
                default: false
        }),
        TGTi: Setting.float({
            name: "Timer",
            default: 4,
            min: 1,
            max: 10
        }),
        XXXXX: Setting.boolean({
                name: " ",
                default: false
        }),
        XXXXXX: Setting.boolean({
                name: "Speed: ",
                default: false
        }),
        Speed: Setting.float({
            name: "Speed",
            default: 2,
            min: 0,
            max: 10
        })
    }
}

var MinemoraGlideModule = {
    name: "MinemoraGlide",
    description: "A Glide Script For Minemora",
    category: "Misc",
    settings: {
        X: Setting.boolean({
            name: "General: ",
            default: false
        }),
        Tick: Setting.float({
            name: "Tick",
            default: 5,
            min: 1,
            max: 10
        }),
        MotionDown: Setting.float({
            name: "MotionDown",
            default: 0.085,
            min: 0,
            max: 1
        }),
        MotionUp: Setting.float({
            name: "MotionUp",
            default: 0.031,
            min: 0,
            max: 1
        }),
        Timer: Setting.float({
            name: "Timer",
            default: 0.7,
            min: 0.3,
            max: 1
        }),
        XX: Setting.boolean({
        	name: " ",
        	default: false
        }),
        Debug: Setting.boolean({
                name: "Debug",
                default: false
        })
    }
}